"""Provision only this project's Azure resources using the current Azure CLI login.

Credentials are generated locally and DPAPI encrypted for the current Windows user.
No credentials are printed or written to the deployment manifest.
"""
import argparse
import json
import os
from pathlib import Path
import secrets
import subprocess
import shutil
import tempfile
import requests
import socket
import urllib3.util.connection

# The host's IPv6 route to Microsoft sign-in is unavailable; keep TLS verified.
urllib3.util.connection.allowed_gai_family = lambda: socket.AF_INET

ROOT = Path(__file__).resolve().parents[1]
LOCAL = ROOT / ".local"
LOCAL.mkdir(exist_ok=True)
SUB = "c2383fdd-26a3-44a8-9d61-2c7f2e1e08bf"
RG = "rg-giftzee-medallion-20261028"
REGION = "eastus"
SQL_REGION = "centralindia"
BASE = f"/subscriptions/{SUB}/resourceGroups/{RG}"
NAMES = {"workspace": "dbw-giftzee-medallion-20261028", "blob": "gzblobc23820261028",
         "adls": "gzadlsc23820261028", "sql": "gz-sql-c238-ci-20261028", "database": "giftzee_demo"}
TOKENS = {}

def cli(*args):
    azure_python = Path(r"C:\Program Files\Microsoft SDKs\Azure\CLI2\python.exe")
    command = [str(azure_python), "-IB", str(ROOT / "scripts/azure_cli_ipv4.py")] if azure_python.exists() else ["az.cmd"]
    env = dict(os.environ)
    if "2ff814a6-3304-4ab8-85cb-cd0e6f879c1d" in args:
        env["AZURE_CORE_ENABLE_BROKER_ON_WINDOWS"] = "false"
    with tempfile.TemporaryFile(mode="w+", encoding="utf-8") as out, tempfile.TemporaryFile(mode="w+", encoding="utf-8") as err:
        process = subprocess.Popen([*command, *args, "-o", "json", "--only-show-errors"], stdout=out, stderr=err, stdin=subprocess.DEVNULL, env=env)
        try:
            process.wait(timeout=45)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)
            raise RuntimeError("Azure CLI authentication timed out; an interactive sign-in may be required") from None
        err.seek(0)
        if process.returncode:
            raise RuntimeError(err.read())
        out.seek(0)
        return json.load(out)

def token(resource="https://management.azure.com/"):
    if resource not in TOKENS:
        TOKENS[resource] = cli("account", "get-access-token", "--resource", resource)["accessToken"]
    return TOKENS[resource]

def arm(method, path, version, data=None):
    r = requests.request(method, "https://management.azure.com" + path,
                         params={"api-version": version}, json=data,
                         headers={"Authorization": "Bearer " + token()}, timeout=90)
    if not r.ok:
        raise RuntimeError(f"ARM {method} {path}: {r.status_code} {r.text[:2000]}")
    return r.json() if r.content else {}

def password(stem="sql-password"):
    path = LOCAL / (stem + ".dpapi")
    command = "$s = ConvertTo-SecureString $env:GIFTZEE_SQL_SECRET -AsPlainText -Force; $s | ConvertFrom-SecureString"
    if not path.exists():
        value = "Gz!" + secrets.token_urlsafe(30) + "a9"
        env = dict(os.environ, GIFTZEE_SQL_SECRET=value)
        r = subprocess.run([shutil.which("pwsh") or "powershell", "-NoProfile", "-Command", command], env=env, capture_output=True, text=True)
        if r.returncode:
            raise RuntimeError(r.stderr.replace(value, "[REDACTED]"))
        path.write_text(r.stdout.strip(), encoding="utf-8")
        return value
    command = "$s = Get-Content -LiteralPath $env:GIFTZEE_SECRET_PATH | ConvertTo-SecureString; [System.Net.NetworkCredential]::new('', $s).Password"
    r = subprocess.run([shutil.which("pwsh") or "powershell", "-NoProfile", "-Command", command],
                       env=dict(os.environ, GIFTZEE_SECRET_PATH=str(path)), capture_output=True, text=True, check=True)
    return r.stdout.strip()

def provision():
    account = cli("account", "show")
    assert account["id"] == SUB and account["user"]["name"].lower() == "giftzee.online@gmail.com"
    print("Confirmed Giftzee subscription", flush=True)
    arm("PUT", BASE, "2022-09-01", {"location": REGION, "tags": {"project": "giftzee-medallion", "environment": "demo"}})
    print("Resource group ready", flush=True)
    path = BASE + "/providers/Microsoft.Databricks/workspaces/" + NAMES["workspace"]
    ws = arm("PUT", path, "2024-05-01", {
        "location": REGION, "sku": {"name": "premium"},
        "tags": {"project": "giftzee-medallion"},
        "properties": {"managedResourceGroupId": f"/subscriptions/{SUB}/resourceGroups/{RG}-managed",
                       "parameters": {"enableNoPublicIp": {"value": True}}}})
    print("Workspace provisioning:", ws.get("properties", {}).get("provisioningState"), flush=True)
    provision_sources()

def provision_sources():
    for kind in ("blob", "adls"):
        data = arm("PUT", BASE + "/providers/Microsoft.Storage/storageAccounts/" + NAMES[kind], "2023-05-01", {
            "location": REGION, "kind": "StorageV2", "sku": {"name": "Standard_LRS"},
            "tags": {"project": "giftzee-medallion"},
            "properties": {"isHnsEnabled": kind == "adls", "minimumTlsVersion": "TLS1_2",
                           "supportsHttpsTrafficOnly": True, "allowBlobPublicAccess": False}})
        print(kind, data.get("properties", {}).get("provisioningState"), flush=True)
    provision_sql()

def provision_sql():
    server = arm("PUT", BASE + "/providers/Microsoft.Sql/servers/" + NAMES["sql"], "2023-08-01", {
        "location": SQL_REGION, "tags": {"project": "giftzee-medallion"},
        "properties": {"version": "12.0", "administratorLogin": "giftzeeadmin",
                       "administratorLoginPassword": password(), "minimalTlsVersion": "1.2",
                       "publicNetworkAccess": "Enabled"}})
    print("SQL server provisioning:", server.get("properties", {}).get("state"), flush=True)
    manifest = json.loads((ROOT / "deployment.json").read_text()) if (ROOT / "deployment.json").exists() else {}
    manifest.update({"subscription": SUB, "resource_group": RG, "region": REGION, "sql_region": SQL_REGION, "names": NAMES})
    (ROOT / "deployment.json").write_text(json.dumps(manifest, indent=2))
    print("Deployment manifest saved", flush=True)

def status():
    resources = arm("GET", BASE + "/resources", "2021-04-01")
    for r in resources.get("value", []):
        print(r["type"], r["name"], flush=True)
    ws = arm("GET", BASE + "/providers/Microsoft.Databricks/workspaces/" + NAMES["workspace"], "2024-05-01")
    print(json.dumps({k: ws.get("properties", {}).get(k) for k in ("provisioningState", "workspaceUrl", "workspaceId")}), flush=True)
    if ws.get("properties", {}).get("workspaceUrl"):
        p = ROOT / "deployment.json"
        m = json.loads(p.read_text()) if p.exists() else {"subscription": SUB, "resource_group": RG, "region": REGION, "names": NAMES}
        m.update({"workspace_url": "https://" + ws["properties"]["workspaceUrl"], "workspace_resource_id": ws["id"]})
        p.write_text(json.dumps(m, indent=2))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["provision", "sources", "sql", "status"])
    args = parser.parse_args()
    {"provision": provision, "sources": provision_sources, "sql": provision_sql, "status": status}[args.action]()
