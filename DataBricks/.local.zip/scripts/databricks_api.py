"""Small authenticated Databricks REST client. Tokens stay in memory."""
import json
import requests
from azure_project import ROOT, token

SESSION = requests.Session()

def manifest():
    return json.loads((ROOT / "deployment.json").read_text())

def db(method, path, data=None):
    m = manifest()
    headers = {"Authorization": "Bearer " + token("2ff814a6-3304-4ab8-85cb-cd0e6f879c1d"),
               "X-Databricks-Azure-Workspace-Resource-Id": m["workspace_resource_id"]}
    r = SESSION.request(method, m["workspace_url"] + path, json=data, headers=headers, timeout=90)
    if not r.ok:
        raise RuntimeError(f"Databricks {path}: {r.status_code} {r.text[:2500]}")
    return r.json() if r.content else {}

if __name__ == "__main__":
    import sys
    print(json.dumps(db("GET", sys.argv[1]), indent=2))
