"""Run the installed Azure CLI with IPv4 transport on this host.

IPv6 addresses for the Microsoft login endpoint time out on this connection.
This affects only this process; TLS certificate verification remains enabled.
"""
import runpy
import socket
import urllib3.util.connection

urllib3.util.connection.allowed_gai_family = lambda: socket.AF_INET
runpy.run_module("azure.cli", run_name="__main__")
