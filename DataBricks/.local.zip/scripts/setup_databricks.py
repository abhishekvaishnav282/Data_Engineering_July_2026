import base64
import json
import sys
from azure_project import ROOT, BASE, RG, NAMES, arm, password
from databricks_api import db, manifest

SCOPE = "giftzee-medallion"
WORKSPACE_PATH = "/Shared/GiftzeeMedallion"

def save(**values):
    m = manifest()
    m.update(values)
    (ROOT / "deployment.json").write_text(json.dumps(m, indent=2))

def setup():
    me = db("GET", "/api/2.0/preview/scim/v2/Me")
    print("Workspace user:", me["userName"], flush=True)
    scopes = db("GET", "/api/2.0/secrets/scopes/list").get("scopes", [])
    if not any(s["name"] == SCOPE for s in scopes):
        db("POST", "/api/2.0/secrets/scopes/create", {"scope": SCOPE, "scope_backend_type": "DATABRICKS"})
    for kind in ("blob", "adls"):
        key = arm("POST", BASE + "/providers/Microsoft.Storage/storageAccounts/" + NAMES[kind] + "/listKeys", "2023-05-01")["keys"][0]["value"]
        db("POST", "/api/2.0/secrets/put", {"scope": SCOPE, "key": kind + "-account-key", "string_value": key})
    for key, value in [("sql-username", "giftzee_pipeline"), ("sql-password", password("sql-reader-password"))]:
        db("POST", "/api/2.0/secrets/put", {"scope": SCOPE, "key": key, "string_value": value})
    print("Secret scope populated; no values logged", flush=True)
    public_ip = arm("GET", f"/subscriptions/{manifest()['subscription']}/resourceGroups/{RG}-managed/providers/Microsoft.Network/publicIPAddresses/nat-gw-public-ip", "2023-09-01")["properties"]["ipAddress"]
    arm("PUT", BASE + "/providers/Microsoft.Sql/servers/" + NAMES["sql"] + "/firewallRules/databricks-project-egress", "2023-08-01", {
        "properties": {"startIpAddress": public_ip, "endIpAddress": public_ip}})
    print("SQL firewall limited to Databricks NAT IP", flush=True)
    versions = db("GET", "/api/2.0/clusters/spark-versions")["versions"]
    version = next(v["key"] for v in versions if v["key"] == "16.4.x-scala2.12")
    nodes = db("GET", "/api/2.0/clusters/list-node-types")["node_types"]
    assert any(n["node_type_id"] == "Standard_D4ds_v4" for n in nodes)
    cluster = {
        "cluster_name": "giftzee-medallion-demo", "spark_version": version,
        "node_type_id": "Standard_D4ds_v4", "num_workers": 0,
        "autotermination_minutes": 15, "data_security_mode": "SINGLE_USER",
        "single_user_name": me["userName"],
        "spark_conf": {"spark.databricks.cluster.profile": "singleNode", "spark.master": "local[*, 4]"},
        "custom_tags": {"ResourceClass": "SingleNode", "project": "giftzee-medallion"},
        "azure_attributes": {"availability": "ON_DEMAND_AZURE"}
    }
    m = manifest()
    if not m.get("cluster_id"):
        result = db("POST", "/api/2.0/clusters/create", cluster)
        save(cluster_id=result["cluster_id"])
        print("Cluster created:", result["cluster_id"], flush=True)
    else:
        print("Reusing this project's cluster:", m["cluster_id"], flush=True)
    (ROOT / "config/cluster.json").write_text(json.dumps(cluster, indent=2))

def upload():
    db("POST", "/api/2.0/workspace/mkdirs", {"path": WORKSPACE_PATH + "/config"})
    for file in (ROOT / "notebooks").glob("*.py"):
        db("POST", "/api/2.0/workspace/import", {
            "path": WORKSPACE_PATH + "/" + file.stem, "language": "PYTHON", "format": "SOURCE",
            "content": base64.b64encode(file.read_bytes()).decode(), "overwrite": True})
    db("POST", "/api/2.0/workspace/import", {
        "path": WORKSPACE_PATH + "/config/sources.json", "format": "AUTO",
        "content": base64.b64encode((ROOT / "config/sources.json").read_bytes()).decode(), "overwrite": True})
    print("Uploaded three notebooks and source config", flush=True)

def command(code):
    cluster_id = manifest()["cluster_id"]
    result = db("POST", "/api/1.2/contexts/create", {"clusterId": cluster_id, "language": "python"})
    context = result["id"]
    result = db("POST", "/api/1.2/commands/execute", {"clusterId": cluster_id, "contextId": context, "language": "python", "command": code})
    save(command_context=context, command_id=result["id"])
    print("Command submitted:", result["id"], flush=True)

def bootstrap():
    command("""spark.sql('CREATE SCHEMA IF NOT EXISTS dbw_giftzee_medallion_20261028.operations')
spark.sql('CREATE VOLUME IF NOT EXISTS dbw_giftzee_medallion_20261028.operations.checkpoints')
print('Catalog and checkpoint volume ready')""")

def command_status():
    m = manifest()
    import urllib.parse
    query = urllib.parse.urlencode({"clusterId": m["cluster_id"], "contextId": m["command_context"], "commandId": m["command_id"]})
    result = db("GET", "/api/1.2/commands/status?" + query)
    if result.get("status") == "Finished" and result.get("results", {}).get("resultType") == "text":
        text = result["results"].get("data", "")
        for line in text.splitlines():
            if line.startswith('{"counts":'):
                validation = dict(json.loads(line), run_id=m["run_id"], job_id=m["job_id"])
                (ROOT / "validation.json").write_text(json.dumps(validation, indent=2))
                history_path = ROOT / "validation-history.json"
                history = json.loads(history_path.read_text()) if history_path.exists() else []
                if not any(v["run_id"] == m["run_id"] for v in history):
                    history.append(validation)
                    history_path.write_text(json.dumps(history, indent=2))
    print(json.dumps(result), flush=True)

def job():
    m = manifest()
    settings = {
        "name": "giftzee-medallion", "max_concurrent_runs": 1, "timeout_seconds": 7200,
        "schedule": {"quartz_cron_expression": "0 0 9 * * ?", "timezone_id": "Asia/Kolkata", "pause_status": "UNPAUSED"},
        "email_notifications": {event: ["bharath.k9898@gmail.com"] for event in ("on_start", "on_success", "on_failure")},
        "parameters": [{"name": "config_path", "default": "/Workspace" + WORKSPACE_PATH + "/config/sources.json"}],
        "tasks": []
    }
    for i, layer in enumerate(("bronze", "silver", "gold"), 1):
        task = {"task_key": layer, "existing_cluster_id": m["cluster_id"], "max_retries": 1,
                "min_retry_interval_millis": 60000,
                "notebook_task": {"notebook_path": WORKSPACE_PATH + f"/0{i}_{layer}", "source": "WORKSPACE"}}
        if i > 1:
            task["depends_on"] = [{"task_key": ("bronze", "silver")[i-2]}]
        settings["tasks"].append(task)
    if m.get("job_id"):
        db("POST", "/api/2.1/jobs/reset", {"job_id": m["job_id"], "new_settings": settings})
    else:
        result = db("POST", "/api/2.1/jobs/create", settings)
        save(job_id=result["job_id"])
    (ROOT / "config/job.json").write_text(json.dumps(settings, indent=2))
    print("Scheduled job:", manifest()["job_id"], flush=True)

def run():
    m = manifest()
    result = db("POST", "/api/2.1/jobs/run-now", {"job_id": m["job_id"]})
    history = m.get("run_history", [m["run_id"]] if m.get("run_id") else [])
    save(run_id=result["run_id"], run_history=[*history, result["run_id"]])
    print("Run submitted:", result["run_id"], flush=True)

def check_job():
    result = db("GET", "/api/2.1/jobs/get?job_id=" + str(manifest()["job_id"]))
    settings = result["settings"]
    assert settings["schedule"]["pause_status"] == "UNPAUSED"
    assert settings["schedule"]["quartz_cron_expression"] == "0 0 9 * * ?"
    assert settings["schedule"]["timezone_id"] == "Asia/Kolkata"
    assert {t["task_key"] for t in settings["tasks"]} == {"bronze", "silver", "gold"}
    for event in ("on_start", "on_success", "on_failure"):
        assert settings["email_notifications"][event] == ["bharath.k9898@gmail.com"]
    print(json.dumps({"job_id": result["job_id"], "schedule": settings["schedule"],
                      "email_notifications": settings["email_notifications"],
                      "creator": result.get("creator_user_name"), "run_as": result.get("run_as_user_name"),
                      "status": "PASS"}, indent=2), flush=True)

def state():
    m = manifest()
    result = db("GET", "/api/2.0/clusters/get?cluster_id=" + m["cluster_id"])
    print(json.dumps({k: result.get(k) for k in ("cluster_id", "node_type_id", "state", "state_message", "termination_reason")}), flush=True)

def output():
    result = db("GET", "/api/2.1/jobs/runs/get-output?run_id=" + sys.argv[2])
    print(json.dumps({k: result.get(k) for k in ("error", "error_trace", "notebook_output")})[:6000], flush=True)

def events():
    result = db("POST", "/api/2.0/clusters/events", {"cluster_id": manifest()["cluster_id"], "order": "DESC", "limit": 5})
    print(json.dumps([{"timestamp": e["timestamp"], "type": e["type"],
                       "reason": e.get("details", {}).get("reason"),
                       "failure": e.get("details", {}).get("add_node_failure_details")}
                      for e in result.get("events", [])], indent=2), flush=True)

def compute_options():
    nodes = db("GET", "/api/2.0/clusters/list-node-types")["node_types"]
    choices = [{"name": n["node_type_id"], "memory_mb": n["memory_mb"], "quota": n.get("node_info")}
               for n in nodes if n["num_cores"] == 4 and n["memory_mb"] >= 14000
               and not n.get("is_hidden") and not n.get("node_info", {}).get("status")
               and n.get("node_info", {}).get("available_core_quota", 0) >= 4]
    print(json.dumps(choices[:25], indent=2), flush=True)

def change_node():
    cluster = json.loads((ROOT / "config/cluster.json").read_text())
    cluster.update({"cluster_id": manifest()["cluster_id"], "node_type_id": sys.argv[2]})
    db("POST", "/api/2.0/clusters/edit", cluster)
    (ROOT / "config/cluster.json").write_text(json.dumps(cluster, indent=2))
    print("Cluster updated:", sys.argv[2], flush=True)

def run_status():
    m = manifest()
    result = db("GET", "/api/2.1/jobs/runs/get?run_id=" + str(m["run_id"]))
    view = {"run_id": result["run_id"], "state": result.get("state"), "run_page_url": result.get("run_page_url"),
            "tasks": [{"task": t["task_key"], "run_id": t["run_id"], "state": t.get("state")} for t in result.get("tasks", [])]}
    (ROOT / "run-status.json").write_text(json.dumps(view, indent=2))
    print(json.dumps(view, indent=2), flush=True)

def verify():
    command("""import json
expected = {'customers': (3,3,0), 'orders': (6,4,1), 'products': (3,3,0)}
counts = {}
for entity, wanted in expected.items():
    got = tuple(spark.table(f'dbw_giftzee_medallion_20261028.{layer}.{entity}').count() for layer in ['bronze','silver','quarantine'])
    assert got == wanted, (entity, got, wanted)
    counts[entity] = got
total = spark.sql('SELECT SUM(revenue) AS revenue FROM dbw_giftzee_medallion_20261028.gold.order_sales').first().revenue
assert str(total) == '3393.00', total
print(json.dumps({'counts': counts, 'total_revenue': str(total), 'status': 'PASS'}))""")

if __name__ == "__main__":
    {"setup": setup, "upload": upload, "bootstrap": bootstrap, "command-status": command_status,
     "job": job, "run": run, "state": state, "events": events, "compute-options": compute_options,
     "change-node": change_node, "run-status": run_status, "verify": verify, "output": output,
     "check-job": check_job}[sys.argv[1]]()
