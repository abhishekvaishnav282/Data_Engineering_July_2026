"""Seed deterministic demo inputs; access is limited to this project's resources."""
import json
import requests
from azure.storage.blob import BlobServiceClient
from azure.core.exceptions import ResourceExistsError
from azure_project import ROOT, BASE, NAMES, SQL_REGION, arm, password
import pymssql

def seed_files():
    customers = [
        {"customer_id": "C001", "customer_name": "Asha Rao", "city": "Hyderabad", "updated_at": "2026-10-28T00:00:00Z"},
        {"customer_id": "C002", "customer_name": "Vikram Shah", "city": "Bengaluru", "updated_at": "2026-10-28T00:00:00Z"},
        {"customer_id": "C003", "customer_name": "Meera Iyer", "city": "Chennai", "updated_at": "2026-10-28T00:00:00Z"},
    ]
    orders = ("order_id,customer_id,product_id,quantity,order_date,updated_at\n"
              "O1001,C001,P001,1,2026-10-27,2026-10-27T10:00:00Z\n"
              "O1001,C001,P001,2,2026-10-27,2026-10-27T11:00:00Z\n"
              "O1002,C002,P002,1,2026-10-27,2026-10-27T11:00:00Z\n"
              "O1003,C001,P003,3,2026-10-28,2026-10-28T01:00:00Z\n"
              "O1004,C003,P001,1,2026-10-28,2026-10-28T02:00:00Z\n"
              ",C003,P001,1,2026-10-28,2026-10-28T03:00:00Z\n")
    for kind, filename, content in [
        ("blob", "customers/batch_001.json", "\n".join(json.dumps(c) for c in customers)),
        ("adls", "orders/batch_001.csv", orders),
    ]:
        account = NAMES[kind]
        key = arm("POST", BASE + "/providers/Microsoft.Storage/storageAccounts/" + account + "/listKeys", "2023-05-01")["keys"][0]["value"]
        service = BlobServiceClient(f"https://{account}.blob.core.windows.net", credential=key)
        try:
            service.create_container("landing")
        except ResourceExistsError:
            pass
        blob = service.get_blob_client("landing", filename)
        try:
            blob.upload_blob(content.encode(), overwrite=False)
            print("Seeded", kind, filename, flush=True)
        except ResourceExistsError:
            print("Seed already exists", kind, filename, flush=True)

def create_database():
    path = BASE + "/providers/Microsoft.Sql/servers/" + NAMES["sql"]
    result = arm("PUT", path + "/databases/" + NAMES["database"], "2023-08-01", {
        "location": SQL_REGION, "sku": {"name": "Basic", "tier": "Basic", "capacity": 5},
        "properties": {"maxSizeBytes": 2147483648, "requestedBackupStorageRedundancy": "Local"}})
    print("Database", result.get("properties", {}).get("status"), flush=True)
    ip = requests.get("https://api.ipify.org", timeout=20).text.strip()
    import ipaddress
    ipaddress.ip_address(ip)
    arm("PUT", path + "/firewallRules/project-bootstrap-client", "2023-08-01", {
        "properties": {"startIpAddress": ip, "endIpAddress": ip}})
    print("Added single-IP bootstrap firewall rule", flush=True)

def seed_sql():
    with pymssql.connect(server=NAMES["sql"] + ".database.windows.net", user="giftzeeadmin@" + NAMES["sql"],
                         password=password(), database=NAMES["database"], login_timeout=30,
                         encryption="require", tds_version="7.4") as conn:
        with conn.cursor() as cursor:
            cursor.execute("""IF OBJECT_ID('dbo.products','U') IS NULL
                CREATE TABLE dbo.products (product_id varchar(16) NOT NULL PRIMARY KEY,
                product_name nvarchar(100) NOT NULL, category nvarchar(50) NOT NULL,
                unit_price decimal(12,2) NOT NULL, updated_at datetime2 NOT NULL)""")
            for row in [("P001", "Keyboard", "Accessories", "499.00"),
                        ("P002", "Monitor stand", "Accessories", "1299.00"),
                        ("P003", "USB cable", "Cables", "199.00")]:
                cursor.execute("""IF NOT EXISTS (SELECT 1 FROM dbo.products WHERE product_id=%s)
                    INSERT INTO dbo.products VALUES (%s,%s,%s,%s,'2026-10-28T00:00:00')""", (row[0], *row))
            cursor.execute("SELECT COUNT(*) FROM dbo.products")
            print("SQL products:", cursor.fetchone()[0], flush=True)
            reader_password = password("sql-reader-password")
            assert "'" not in reader_password
            cursor.execute("SELECT COUNT(*) FROM sys.database_principals WHERE name='giftzee_pipeline'")
            if cursor.fetchone()[0] == 0:
                cursor.execute("CREATE USER giftzee_pipeline WITH PASSWORD = '" + reader_password + "'")
            cursor.execute("GRANT SELECT ON dbo.products TO giftzee_pipeline")
        conn.commit()

def cleanup_bootstrap():
    arm("DELETE", BASE + "/providers/Microsoft.Sql/servers/" + NAMES["sql"] + "/firewallRules/project-bootstrap-client", "2023-08-01")
    print("Removed temporary local bootstrap SQL firewall rule; Databricks NAT rule remains", flush=True)

if __name__ == "__main__":
    import sys
    {"files": seed_files, "database": create_database, "sql": seed_sql, "cleanup-bootstrap": cleanup_bootstrap}[sys.argv[1]]()
