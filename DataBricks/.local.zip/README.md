# Giftzee medallion pipeline

Account: `giftzee.online@gmail.com`. All Azure resources were newly created for this project. Live execution results are recorded separately in `run-status.json` and `validation.json` when available.

Workspace: https://adb-7405614782705324.4.azuredatabricks.net

Job: https://adb-7405614782705324.4.azuredatabricks.net/jobs/653026402511310

Resource group: `rg-giftzee-medallion-20261028`. See `deployment.json` for exact resource identifiers. Databricks and storage are in East US. SQL is in Central India because Azure rejected SQL provisioning in East US for this subscription.

| Resource | Name |
| --- | --- |
| Databricks workspace | dbw-giftzee-medallion-20261028 |
| Blob account | gzblobc23820261028 |
| ADLS Gen2 account | gzadlsc23820261028 |
| SQL logical server | gz-sql-c238-ci-20261028 |
| SQL database | giftzee_demo |
| Unity Catalog catalog | dbw_giftzee_medallion_20261028 |

Three Databricks source notebooks run in sequence:

```mermaid
flowchart LR
  B[Blob: customer JSON] --> NB1[01 Bronze]
  A[ADLS Gen2: order CSV] --> NB1
  S[Azure SQL: products] --> NB1
  NB1 --> BR[(Bronze Delta tables)]
  BR --> NB2[02 Silver]
  NB2 --> SI[(Clean, deduplicated Silver)]
  NB2 --> Q[(Quarantined rows)]
  SI --> NB3[03 Gold]
  Q --> NB3
  NB3 --> G[(Sales and quality tables)]
  T[Daily 09:00 IST or Run Now] --> J[Databricks Job]
  J -. executes in order .-> NB1
  J --> E[Start, success, failure email]
```

1. `01_bronze.py`: multiple configured Blob/ADLS file feeds through Auto Loader with durable per-feed checkpoints; SQL Server tables through encrypted JDBC full snapshots.
2. `02_silver.py`: reject null keys and rescued records into quarantine; deduplicate by configured primary key and latest sequence value with deterministic tie breaking.
3. `03_gold.py`: join customers, orders, and products; publish `gold.order_sales`, `gold.daily_sales`, `gold.customer_sales`, and `gold.pipeline_quality_summary`.

The included retail data is synthetic demo data, not Giftzee production data. Customers arrive as JSON from standard Blob Storage, orders as CSV from ADLS Gen2, and products from an Azure SQL Database (SQL Server engine) through JDBC. Azure SQL Database is a managed source, not a SQL Server virtual machine.

Expected results: three customers, six raw order rows, three products; Silver contains four unique orders; one order with a missing key is quarantined; Gold revenue totals `3393.00` in demo currency units. Two versions of order O1001 demonstrate deduplication using the latest timestamp.

Add more feeds to `config/sources.json` with unique names and checkpoints. Do not reuse checkpoints for a different source or change primary keys without a migration plan.

## Workspace prerequisites

- Dedicated single-user cluster `giftzee-medallion-demo`, Runtime 16.4 LTS, one `Standard_D4ds_v4` node, auto-termination after 15 minutes idle. Jobs start the cluster automatically when required.
- Unity Catalog workspace catalog `dbw_giftzee_medallion_20261028` with Bronze, Silver, Gold, quarantine, and operations schemas.
- Checkpoints under `/Volumes/dbw_giftzee_medallion_20261028/operations/checkpoints/giftzee`.
- Private Blob containers, HTTPS/TLS, and storage account keys referenced through the Databricks secret scope `giftzee-medallion`.
- SQL pipeline user `giftzee_pipeline` has SELECT only on `dbo.products`. SQL ingress is limited to explicit IP rules, including the workspace NAT address.
- Generated SQL credentials are encrypted with Windows DPAPI under ignored `.local/`, tied to the current Windows user. Do not delete those files unless rotating the credentials. Secrets are never included in `deployment.json`.

## Configure and deploy

The project was deployed through the REST scripts in `scripts/`. Local scripts require Windows, PowerShell 7, Azure CLI, the Giftzee Azure login, and `pip install -r requirements.txt`. The IPv4 CLI wrapper avoids this host's unavailable IPv6 route to Microsoft sign-in without changing host networking or TLS validation.

The deployed job is linked above. Run and inspect it using the following commands. Wait for the job to finish successfully before `verify`; that command requires the cluster to be running.

Use the intended workspace explicitly:

```powershell
python scripts/setup_databricks.py run
python scripts/setup_databricks.py run-status
python scripts/setup_databricks.py verify
python scripts/setup_databricks.py command-status
```

To update the existing job and notebooks after editing local sources:

```powershell
python scripts/setup_databricks.py upload
python scripts/setup_databricks.py job
```

The deployed schedule is daily at 09:00 Asia/Kolkata, enabled. `config/job.json` records its settings. Only one concurrent job run is allowed. Azure and Databricks usage incurs charges; compute auto-terminates, but SQL and storage continue to exist. Pause the job and terminate the cluster in Databricks when no longer using the demo.

`databricks.yml` is an optional bundle deployment definition; it is not the state manager for the REST-deployed job. Deploying it without importing/binding the existing job would create a separate job. Do not run separate jobs against the same tables/checkpoints concurrently.

Email notifications are configured for start, success and failure to `bharath.k9898@gmail.com`, including manual job runs. Delivery must be confirmed through a real run and the recipient's inbox. Job retries can resolve transient failures; failures propagate to downstream tasks. Maximum one concurrent run is configured within each job.

## Validation and operational limits

Local Python syntax compilation passed. Check `run-status.json` for live task results and `validation.json` for validated data counts when generated. Email notification settings can be verified through the job configuration; inbox delivery requires checking the recipient's mailbox.

The first live run `529488600811000` completed successfully across all three tasks. Independent Spark assertions passed with the following results:

| Entity | Bronze | Silver | Quarantine |
| --- | ---: | ---: | ---: |
| Customers | 3 | 3 | 0 |
| Orders | 6 | 4 | 1 |
| Products | 3 | 3 | 0 |

Gold order revenue: `3393.00`. `validation-history.json` records independent checks by run ID. The live job's schedule, email settings, creator, and run-as user were read back and verified with `python scripts/setup_databricks.py check-job`.

Replay run `1032012829926275` also completed successfully across all three tasks. Independent Spark assertions confirmed exactly the same counts and revenue after replay: no duplicate file ingestion. Notification configuration is verified; recipient inbox delivery has not been independently checked.

For future changes, use known source records and repeat the replay check. The included null-key row exercises quarantine. SQL snapshots propagate source deletions on the next successful refresh; deletion propagation has not been separately exercised in this demo. Check job output and the recipient inbox for notifications.

Each Delta table update is atomic, but publishing several tables is not a cross-table transaction. On a failed run, previous Gold outputs remain visible and some earlier layers may have advanced. Silver and SQL Bronze use full table overwrites and fail on incompatible schema changes. SQL ingestion is a full snapshot, not CDC. File feeds expect immutable arriving files and do not mirror source deletions. Gold checks for unmatched customer/product references and fails instead of silently dropping orders. Quarantine metrics describe current Bronze contents, not only the latest job run.

The three feeds form a small demo; source-specific data contracts, CDC, schema migrations, private networking, service-principal ownership, and production-scale incremental Silver/Gold processing need further design before using production data.

Official references: [bundle examples](https://learn.microsoft.com/en-us/azure/databricks/dev-tools/bundles/examples), [scheduled Auto Loader batches](https://learn.microsoft.com/en-us/azure/databricks/ingestion/cloud-object-storage/auto-loader/production).
